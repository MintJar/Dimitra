<!-- pagination -->
<div class="pagination">
	<?php emilywp_pagination(); ?>
</div>
<!-- /pagination -->
